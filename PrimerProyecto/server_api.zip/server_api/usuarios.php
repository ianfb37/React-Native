<?php
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

// --- PETICIONES GET (Login o Perfil) ---
if ($method == 'GET') {
    
    // CASO A: Obtener Perfil Actual (si viene id_usuario)
    if (isset($_GET['id_usuario'])) {
        $id = $_GET['id_usuario'];
        $stmt = $conn->prepare("SELECT id, nombre, imagen FROM mw208_RecetasUsuarios WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {
            echo json_encode([
                "success" => true,
                "id" => $user['id'],
                "nombre" => $user['nombre'],
                "imagen" => $user['imagen']
            ]);
        } else {
            http_response_code(404);
            echo json_encode(["error" => "Usuario no encontrado"]);
        }
        exit;
    }

    // CASO B: Login (si vienen nombre y contraseña)
    $nombre = $_GET['nombre'] ?? '';
    $pass = $_GET['contraseña'] ?? '';

    if (!empty($nombre) && !empty($pass)) {
        $stmt = $conn->prepare("SELECT id, nombre, contraseña, imagen FROM mw208_RecetasUsuarios WHERE nombre = ?");
        $stmt->bind_param("s", $nombre);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {
            if ($user['contraseña'] === $pass) {
                echo json_encode([
                    "success" => true,
                    "id" => $user['id'],
                    "usuario" => $user['nombre'],
                    "imagen" => $user['imagen']
                ]);
            } else {
                http_response_code(401);
                echo json_encode(["error" => "Contraseña incorrecta"]);
            }
        } else {
            http_response_code(404);
            echo json_encode(["error" => "Usuario no encontrado"]);
        }
        exit;
    }
    
    // Si no es ninguno de los anteriores
    echo json_encode(["error" => "Petición GET no válida"]);
}

// --- PETICIONES POST (Registro) ---
if ($method == 'POST') {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    $nombre = $data['nombre'] ?? '';
    $pass = $data['password'] ?? ''; 
    $imagen = "/assets/default.jpg";

    if (empty($nombre) || empty($pass)) {
        echo json_encode(["error" => "Datos incompletos"]);
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO mw208_RecetasUsuarios (nombre, contraseña, imagen) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $nombre, $pass, $imagen);

    if ($stmt->execute()) {
        echo json_encode([
            "success" => true, 
            "id" => $stmt->insert_id,
            "imagen" => $imagen
        ]);
    } else {
        echo json_encode(["error" => $conn->error]);
    }
}
?>