<?php
// Configuración de la base de datos
$host = 'localhost'; // Al estar en el mismo servidor, usa localhost
$user = 'busan_formacion';
$pass = 'formacion';
$db   = 'busan_formacion';

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die(json_encode(["error" => "Error de conexión: " . $conn->connect_error]));
}

// Para que acepte acentos y Ñ
$conn->set_charset("utf8");

// Cabeceras CORS para que tu App de Expo pueda entrar
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

// Manejar peticiones OPTIONS (Preflight)
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit;
}
?>