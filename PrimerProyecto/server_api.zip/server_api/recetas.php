<?php
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

// --- 1. OBTENER RECETAS (GET) ---
if ($method == 'GET') {
    // Seleccionamos los campos exactos de tu tabla
    $sql = "SELECT id, estado, nombre, descripcion, fecha, imagen, firma, orden FROM mw208_Recetas ORDER BY id DESC";
    $result = $conn->query($sql);
    $recetas = [];

    if ($result) {
        while($row = $result->fetch_assoc()) {
            $recetas[] = $row;
        }
        echo json_encode($recetas);
    } else {
        echo json_encode(["error" => $conn->error]);
    }
    exit;
}

// --- 2. SUBIR NUEVA RECETA (POST) ---
if ($method == 'POST') {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    // Mapeamos los datos que vienen de la App a tus columnas
    $nombre = $data['nombre'] ?? 'Sin nombre';
    $descripcion = $data['descripcion'] ?? '';
    $imagen = $data['imagen'] ?? '';
    $estado = $data['estado'] ?? 1; // Valor por defecto
    $firma = $data['firma'] ?? 'Usuario';
    $orden = $data['orden'] ?? 0;
    $fecha = date('Y-m-d H:i:s'); // Fecha actual

    $stmt = $conn->prepare("INSERT INTO mw208_Recetas (estado, nombre, descripcion, fecha, imagen, firma, orden) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssssi", $estado, $nombre, $descripcion, $fecha, $imagen, $firma, $orden);

    if ($stmt->execute()) {
        echo json_encode([
            "success" => true, 
            "id" => $stmt->insert_id,
            "mensaje" => "Receta guardada correctamente"
        ]);
    } else {
        echo json_encode(["error" => $conn->error]);
    }
    exit;
}
?>