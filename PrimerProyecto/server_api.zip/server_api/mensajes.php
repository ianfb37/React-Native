<?php
require_once 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

// --- 1. OBTENER CONTACTOS (GET con modo=contactos) ---
if ($method == 'GET' && isset($_GET['modo']) && $_GET['modo'] == 'contactos') {
    $sql = "SELECT id, nombre FROM mw208_RecetasUsuarios ORDER BY nombre ASC";
    $result = $conn->query($sql);
    $contactos = [];
    while($row = $result->fetch_assoc()) {
        $contactos[] = $row;
    }
    echo json_encode($contactos);
    exit;
}

// --- 2. LEER MENSAJES (GET con receptor) ---
if ($method == 'GET' && isset($_GET['receptor'])) {
    $receptor = $_GET['receptor'];
    // NOTA: En un sistema real usaríamos el ID de sesión. 
    // Para este ejemplo, simulamos que "yo" soy el ID 1 o lo que definas.
    $miId = 1; 

    $stmt = $conn->prepare("SELECT id, id_emisor, id_receptor, contenido, fecha_envio FROM mw208_RecetasMensajes 
                            WHERE (id_emisor = ? AND id_receptor = ?) 
                            OR (id_emisor = ? AND id_receptor = ?) 
                            ORDER BY fecha_envio ASC");
    $stmt->bind_param("iiii", $miId, $receptor, $receptor, $miId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $mensajes = [];
    while($row = $result->fetch_assoc()) {
        $mensajes[] = $row;
    }
    echo json_encode($mensajes);
    exit;
}

// --- 3. ENVIAR MENSAJE (POST) ---
if ($method == 'POST') {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    $id_emisor = 1; // Aquí deberías usar el ID del usuario logueado
    $id_receptor = $data['id_receptor'] ?? 0;
    $contenido = $data['contenido'] ?? '';

    if ($id_receptor > 0 && !empty($contenido)) {
        $stmt = $conn->prepare("INSERT INTO mw208_RecetasMensajes (id_emisor, id_receptor, contenido) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $id_emisor, $id_receptor, $contenido);
        
        if ($stmt->execute()) {
            echo json_encode(["success" => true]);
        } else {
            echo json_encode(["error" => $conn->error]);
        }
    }
    exit;
}
?>