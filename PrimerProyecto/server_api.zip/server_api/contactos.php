<?php
require_once 'db.php';

// Solo necesitamos GET para ver la lista de personas
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $sql = "SELECT id, nombre, imagen FROM mw208_RecetasUsuarios";
    $result = $conn->query($sql);
    $usuarios = [];

    while($row = $result->fetch_assoc()) {
        $usuarios[] = $row;
    }
    echo json_encode($usuarios);
}
?>